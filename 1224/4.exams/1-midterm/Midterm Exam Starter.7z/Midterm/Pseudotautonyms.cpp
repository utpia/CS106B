#include "Pseudotautonyms.h"
using namespace std;

bool isPseudotautonym(const string& str) {
    /* TODO: Delete this comment and the lines after it, then
     * implement this function.
     */
    (void) str;
    return {};
}

/************************************************************************
 * You are encouraged to - but not required to - add custom tests here. *
 ************************************************************************/

#include "GUI/SimpleTest.h"
