WINDOW_TITLE("CS106B Midterm Exam")

INITIAL_HANDLER("TestingGUI.cpp")

TEST_ORDER("Pseudotautonyms.cpp",
           "PseudotautonymsTests.cpp",
           "Amoebas.cpp",
           "AmoebasTests.cpp",
           "CareTeams.cpp",
           "CareTeamsTests.cpp",
           "PeakeSequences.cpp",
           "PeakeSequencesTests.cpp")
