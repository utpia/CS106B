#include "Amoebas.h"
using namespace std;

Vector<Grid<bool>> simulateAmoebas(const Grid<bool>& world) {
    /* TODO: Delete this comment and the lines after it, then
     * implement this function.
     */
    (void) world;
    return {};
}

/************************************************************************
 * You are encouraged to - but not required to - add custom tests here. *
 ************************************************************************/

#include "GUI/SimpleTest.h"
