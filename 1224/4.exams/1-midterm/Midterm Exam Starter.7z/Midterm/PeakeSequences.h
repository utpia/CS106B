#pragma once

#include <string>

/* Given a number n, returns the number of Peake sequences
 * that evaluate to n.
 */
int numPeakeSequencesFor(int n);
