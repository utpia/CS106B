#include "CareTeams.h"
using namespace std;

Set<Set<Triad>> allCareTeamsFor(const Set<string>& doctors,
                                const Set<string>& residents,
                                const Set<string>& patients) {
    /* TODO: Delete this comment and the lines after it, then
     * implement this function.
     */
    (void) doctors;
    (void) residents;
    (void) patients;
    return {};
}

/************************************************************************
 * You are encouraged to - but not required to - add custom tests here. *
 ************************************************************************/

#include "GUI/SimpleTest.h"
