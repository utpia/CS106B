#include "PeakeSequences.h"
#include "GUI/SimpleTest.h"
#include "Demos/Timer.h"
using namespace std;

PROVIDED_TEST("Counts Peake sequences for small numbers.") {
    EXPECT_EQUAL(numPeakeSequencesFor(3), 6);
    EXPECT_EQUAL(numPeakeSequencesFor(10), 1008);
}

PROVIDED_TEST("Stress Test: Handles large inputs.") {
    /* TODO: Yes, we are asking you to make a change to this test case! Delete the
     * line immediately after this one - the one that starts with SHOW_ERROR - once
     * you have implemented memoization to test whether it works correctly.
     */
    SHOW_ERROR("This test is configured to always fail until you delete this line from\n         PeakeSequencesTests.cpp. Once you have implemented memoization and want\n         to check whether it works correctly, remove the indicated line.");

    Timing::Timer timer;
    timer.start();
    EXPECT_EQUAL(numPeakeSequencesFor(31), 2123121900);
    timer.stop();

    /* Computing the above value should be essentially instantaneous. */
    EXPECT_LESS_THAN_OR_EQUAL_TO(timer.timeInSeconds(), 0.1);
}
