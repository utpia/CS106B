#include "PeakeSequences.h"
using namespace std;

int numPeakeSequencesFor(int n) {
    /* TODO: Delete this comment and the lines after it, then
     * implement this function.
     */
    (void) n;
    return {};
}

/************************************************************************
 * You are encouraged to - but not required to - add custom tests here. *
 ************************************************************************/

#include "GUI/SimpleTest.h"
